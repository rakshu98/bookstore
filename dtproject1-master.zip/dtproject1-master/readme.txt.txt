# Book Store

This website is based on Eccommerce project.
The project is created using Maven webapp.


## Getting Started



#### Technology used

1. HTML5
2. Javascript
3. Bootstrap
4. Angular JS
5. Java